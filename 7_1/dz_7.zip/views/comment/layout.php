<header>
    <h2><?= $title ?></h2>
</header>

<main class="container-fluid" role="main">
    <?= $view ?>
</main>