<?php

function startup() {
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbName = "php2";

    setlocale(LC_ALL, "ru_RU.UTF-8");
    mb_internal_encoding("UTF-8");

    mysql_connect($hostname, $username, $password) or die("Error");
    mysql_query("SET NAMES utf8");
    mysql_select_db($dbName) or die("Error");

}

?>