<h1>MVC Example</h1>
<a href="editor.php">Control Panel</a>