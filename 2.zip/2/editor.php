<?php

include_once("startup.php");
include_once("model.php");

startup();

$articles = article_all();

header("Content-type: text/html; charset=utf-8");

include("theme/editor.php");

?>