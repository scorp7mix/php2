<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New</title>
</head>
<body>
    <h1>New Article</h1>

    <form action="" method="POST">
        Title:<br>
        <input type="text" name="title" value="<?=$title?>"/>
        <br>
        Content:<br>
        <textarea name="content"><?=$content?></textarea>
        <input type="submit" value="Create"/>
    </form>
</body>
</html>