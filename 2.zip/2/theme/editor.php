<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Editor</title>
</head>
<body>
    <h1>Editor</h1>
    <hr/>

    <ul>
        <li><a href="new.php">New Article</a></li>
        <?php foreach($articles as $article): ?>
        <li>
            <a href="edit.php?id=<?=$article['id_article']?>"><?=$article['title']?></a>
        </li>
        <?php endforeach ?>
    </ul>
</body>
</html>