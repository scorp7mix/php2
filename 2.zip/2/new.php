<?php

include_once("startup.php");
include_once("model.php");

startup();

if(!empty($_POST)){
    if(article_new($_POST['title'], $_POST['content'])){
        header("Location: editor.php");
        die();
    }

    $title = $_POST['title'];
    $content = $_POST['content'];
} else {
    $title = "";
    $content = "";
}


header("Content-type: text/html; charset=utf-8");

include("theme/new.php");

?>