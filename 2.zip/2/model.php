<?php

function article_all()
{
    $query = "SELECT * FROM articles ORDER BY id DESC";
    $result = mysql_query($query);
    if(!$result)
        die(mysql_error());

    $n = mysql_num_rows($result);
    $articles = [];
    for($i = 0; $i < $n; $i++) {
        $row = mysql_fetch_assoc($result);
        $articles[] = $row;
    }
    return $articles;
}

function article_get($id_article)
{

}

function article_new($title, $content)
{
    $title = trim($title);
    $content = trim($content);

    if($title == "") return false;

    $t = "INSERT INTO articles (title, text) VALUES ('%s', '%s')";
    $query = sprintf($t, mysql_real_escape_string($title), mysql_real_escape_string($content));
    $result = mysql_query($query);

    if(!$result) die (mysql_error());

    return true;
}

function article_edit($id_article, $title, $content)
{

}


function article_delete($id_article)
{

}

function article_intro($article)
{

}

?>