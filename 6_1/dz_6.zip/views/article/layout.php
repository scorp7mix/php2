<header class="page-header">
    <h1><?= $title ?></h1>
</header>

<menu class="nav nav-pills">
    <?= $menu ?>
</menu>

<hr>

<main class="container-fluid" role="main">
    <?= $view ?>
</main>