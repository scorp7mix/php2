<div class="jumbotron">

    <h3 class="text-center"><?= $comment['user'] ?></h3>

    <hr>

    <p><?= $comment['text'] ?></p>

</div>
