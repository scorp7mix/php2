<div class="jumbotron">

    <h3 class="text-center"><?= $article['title'] ?></h3>

    <hr>

    <p><?= $article['content'] ?></p>

</div>

<?= $comments ?>

<?= $new_comment_form ?>